import ply.lex as lex

# Daftar token
tokens = (
    'CAT', 'NUMBER', 'ASSIGN', 'GT', 'IF', 'ELSE', 'STRING', 'LPAREN', 'RPAREN', 
    'LCURLY', 'RCURLY', 'SEMICOLON', 'COMMA', 'ID'
)

# Definisi token
t_CAT = r'\bcat\b'        # Definisikan 'cat' dengan boundary word
t_IF = r'\bif\b'          # Definisikan 'if' dengan boundary word
t_ELSE = r'\belse\b'      # Definisikan 'else' dengan boundary word
t_ASSIGN = r'<-'
t_GT = r'>'
t_STRING = r'\"([^"\\]|(\\.)|(\n))*\"'
t_LPAREN = r'\('
t_RPAREN = r'\)'
t_LCURLY = r'\{'
t_RCURLY = r'\}'
t_SEMICOLON = r';'
t_COMMA = r','
t_ID = r'[a-zA-Z_][a-zA-Z_0-9]*'
t_NUMBER = r'\d+'

# Ignore whitespace and comments
t_ignore = ' \t'
t_ignore_COMMENT = r'\#.*'

# Handling newline
def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

# Error handling
def t_error(t):
    print(f"Illegal character '{t.value[0]}'")
    t.lexer.skip(1)

# Build lexer
lexer = lex.lex()

# Contoh input
data = '''num1 <- 10
num2 <- 20
if (num1 > num2) {
    bignum <- num1;
    cat("Big Number is ", bignum, "\n")
} else {
    bignum <- num2;
    cat("Big Number is ", bignum, "\n")
}
'''

# Tokenizing
lexer.input(data)
for tok in lexer:
    print(tok)